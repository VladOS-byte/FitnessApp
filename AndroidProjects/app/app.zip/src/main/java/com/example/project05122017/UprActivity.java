package com.example.project05122017;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

import com.jjoe64.graphview.GraphView;
import com.jjoe64.graphview.series.DataPoint;
import com.jjoe64.graphview.series.LineGraphSeries;

public class UprActivity extends AppCompatActivity {
    String[] names={};
    String[] I={};
    String[] videos={};//ресурсы для видео и описания


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Intent intent=getIntent();
        String name=intent.getStringExtra("name");
        int i;
        for (i=0;i<names.length;i++) {
            if(names[i].equals(name))
                break;
        }
        TextView textView0=(TextView)findViewById(R.id.textView);
        textView0.setText(names[i]);
        TextView textView1=(TextView)findViewById(R.id.textView1);
        textView1.setText(I[i]);
        TextView textView2=(TextView)findViewById(R.id.textView2);
        textView2.setText(videos[i]);
        GraphView graphView=(GraphView)findViewById(R.id.graph);
        LineGraphSeries<DataPoint> series =new LineGraphSeries<>(new DataPoint[]{
                new DataPoint(0,1),
                new DataPoint(5,8),
                new DataPoint(-1,4)
        });
        graphView.addSeries(series);
    }

}
