package com.example.project05122017;

import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;

public class HomeActivity extends AppCompatActivity {
    ImageButton imageButton;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        imageButton=(ImageButton)findViewById(R.id.imagebutton);
    }

    public void onClickMainScreen(View view) {
        switch (view.getId()){
            case R.id.imagebutton:{
                Intent intent=new Intent(this,SettingActivity1.class);
                startActivity(intent);
                break;
            }
            case R.id.button0:
            {
                Intent intent=new Intent(this,OutdoorsActivity.class);
                startActivity(intent);
                break;
            }
            case R.id.button2:
            {
                Intent intent=new Intent(this,WorkoutActivity.class);
                startActivity(intent);
                break;
            }
            case R.id.buttonExit:
            {
                dialog();
                break;
            }
            case R.id.button4:
            {
                Intent intent=new Intent(this,TrenZalActivity.class);
                startActivity(intent);
                break;
            }
            case R.id.button5:
            {
                Intent intent=new Intent(this,SportZalActivity.class);
                startActivity(intent);
                break;
            }
        }

    }

    @Override
    public void onBackPressed(){
        //эмулируем нажатие на HOME, сворачивая приложение
        Intent i = new Intent(Intent.ACTION_MAIN);
        i.addCategory(Intent.CATEGORY_HOME);
        i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        startActivity(i);
    }

    private void dialog(){
        AlertDialog.Builder al=new AlertDialog.Builder(this);
        al.setTitle("Exit: Are  you sure?");
        al.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {/***/}
        });
        al.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                exit();
            }

        });
        al.show();
    }
    private void exit() {
        getApplicationContext().deleteFile("FileToRegistr");
        Intent intent=new Intent(this,MainActivity.class);
        startActivity(intent);
    }

}

