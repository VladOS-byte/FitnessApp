package com.example.project05122017;

import android.os.AsyncTask;
import android.util.Log;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;


class Sender extends AsyncTask<String,Integer,String>{
    final String LOG_TAG = "myLogs";
    @Override
    protected String doInBackground(String... command0) {
        try {
            Log.d(LOG_TAG,"start");
        Socket connection = new Socket("185.228.233.53", 1012);
        ObjectOutputStream os = new ObjectOutputStream(connection.getOutputStream());
        ObjectInputStream is = new ObjectInputStream(connection.getInputStream());
        os.writeObject(command0);
        os.flush();
        long start=System.currentTimeMillis();
            Log.d(LOG_TAG,"wait");
        while (!connection.isClosed()&&System.currentTimeMillis()-start<2000){
            String answer = is.readUTF();
            if (!answer.equals("")){
                Log.d(LOG_TAG,"ans");
                os.writeObject("quit");
                os.flush();
                return answer;
            }
        }
            Log.d(LOG_TAG,"finish");
    } catch (IOException e){
        e.printStackTrace();
            Log.d(LOG_TAG,"h");
    }
        Log.d(LOG_TAG,"hh");
        return "ERROR ANSWER";
    }
}