package com.example.project05122017;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Environment;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.util.Linkify;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.util.concurrent.ExecutionException;

public class RegistrationActivity extends Activity {

    EditText editText0;
    EditText editText1;
    EditText editText2;
    EditText editText3;
    EditText editText4;
    int a=0;
    EditText editText5;
    Boolean sav=false;
    Boolean b0;
    Boolean b1;
    Boolean b2;
    Boolean b3;
    Boolean b4;
    Boolean b5;
    final int DIALOG_POLITE=1;
    RadioButton rb;
    Button buttonOk;
    @SuppressLint("SetTextI18n")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration);
        TextView textView=(TextView)findViewById(R.id.textView);
        textView.setText("@string/polite");
        Linkify.addLinks(textView, Linkify.ALL);
        editText0 = (EditText) findViewById(R.id.editText0);
        editText1 = (EditText) findViewById(R.id.editText1);
        editText2 = (EditText) findViewById(R.id.editText2);
        editText3 = (EditText) findViewById(R.id.editText3);
        editText4 = (EditText) findViewById(R.id.editText4);
        editText5 = (EditText) findViewById(R.id.editText5);
        rb=(RadioButton)findViewById(R.id.radioButton);
        buttonOk = (Button) findViewById(R.id.buttonOk);
        buttonOk.setClickable(false);
    }

    protected Dialog onCreateDialog(int id){
        if(id==DIALOG_POLITE){
            final AlertDialog.Builder adb = new AlertDialog.Builder(this);
            // заголовок
            adb.setTitle("Privacy Policy");
            // сообщение
            adb.setMessage(R.string.Privacy);
            // кнопка положительного ответа
            adb.setPositiveButton("I'm agree", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    buttonOk.setClickable(true);
                    rb.toggle();
                    Toast.makeText(getApplicationContext(), "Saving", Toast.LENGTH_SHORT).show();
                }
            });
            // кнопка отрицательного ответа
            adb.setNegativeButton("Cancel",new DialogInterface.OnClickListener(){
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {}
            });
            // кнопка нейтрального ответа
            return adb.create();
        }

        return super.onCreateDialog(id);
    }
    public boolean isOnline() {
        ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        try {
            NetworkInfo netInfo = cm.getActiveNetworkInfo();
            return netInfo != null && netInfo.isConnectedOrConnecting();
        } catch (NullPointerException e) {
            return false;
        }
    }
    public void Registrate(View v) {
        switch (v.getId()) {
            case R.id.radioButton:
                buttonOk.setClickable(true);
                break;
            case R.id.textView:{
                showDialog(DIALOG_POLITE);
                break;
            }
            case R.id.switch0:{
                a++;
                sav = a % 2 != 0;
                break;
            }
            case R.id.buttonOk:{
                b0 = editText0.getText().toString().equals("");
                b1 = editText1.getText().toString().equals("");
                b2 = editText2.getText().toString().equals("");
                b3 = editText3.getText().toString().equals("");
                b4 = editText4.getText().toString().equals("");
                b5 = editText5.getText().toString().equals("");
                String login = editText0.getText().toString();
                String password = editText1.getText().toString();
                String height = editText2.getText().toString();
                String wight = editText3.getText().toString();
                String name = editText4.getText().toString();
                String mail = editText5.getText().toString();


                if (b0)
                    editText0.setBackgroundResource(R.color.colorAccent);
                if (b1)
                    editText1.setBackgroundResource(R.color.colorAccent);
                if (b2)
                    editText2.setBackgroundResource(R.color.colorAccent);
                if (b3)
                    editText3.setBackgroundResource(R.color.colorAccent);
                if (b4)
                    editText4.setBackgroundResource(R.color.colorAccent);
                if (b5)
                    editText5.setBackgroundResource(R.color.colorAccent);
                if(b1||b0||b2||b3||b4||b5){
                    break;
                }
                else{
                    //SAVE
                    TextView tv=(TextView)findViewById(R.id.tv1);
                    if (isOnline()){
                        String s= null;
                        try {
                            s = new Sender().execute("writeNEW",login,password,mail,wight,height,name).get();
                            if(s.equals("ERROR")){
                                    tv.setText("Your login are used");
                                    break;
                                }
                            if(s.equals("ERROR ANSWER")){
                                    tv.setText("Server is not available");
                                    break;
                                }
                        } catch (InterruptedException | ExecutionException e) {
                            tv.setText("Server is not available");
                            break;
                        }

                    }
                    else
                        tv.setText("No network connection! Please, try to LogIn after resume coonection.");
                    File file0=new File(getApplicationContext().getFilesDir()+"/"+"MyFyles","FileToRecords");
                    File file1=new File(getApplicationContext().getFilesDir()+"/"+"MyFyles","FileToResults");
                    if(sav){File file=new File(getApplicationContext().getFilesDir()+"/"+"MyFyles","FileToRegistr");

                    try {
                        FileOutputStream outputStream=openFileOutput("FileToRegistr", Context.MODE_PRIVATE);
                        outputStream.write((login+"\n").getBytes());
                        outputStream.write((password+"\n").getBytes());
                        outputStream.write((name+"\n").getBytes());
                        outputStream.write((mail+"\n").getBytes());
                        outputStream.write((height+"\n").getBytes());
                        outputStream.write((wight+"\n").getBytes());
                    } catch (IOException ignored){}}
                    Toast.makeText(getApplicationContext(), "Welcome, "+name+"!", Toast.LENGTH_LONG).show();
                    Intent intent1 = new Intent(this, HomeActivity.class);
                    startActivity(intent1);
                    break;
                }}

        }
    }
}