package com.example.project05122017;

import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

public class WorkoutActivity extends AppCompatActivity{
    String[] names={};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_workout);
        final ListView listView=(ListView)findViewById(R.id.lv);
        ArrayAdapter<String> adapter=new ArrayAdapter<String>(this,R.layout.mylist_item0,names);
        listView.setAdapter(adapter);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Button button=(Button) view;
                Intent intent=new Intent(WorkoutActivity.this,UprActivity.class);
                intent.putExtra("name", button.getText().toString());
                startActivity(intent);
            }
        });
    }

}
