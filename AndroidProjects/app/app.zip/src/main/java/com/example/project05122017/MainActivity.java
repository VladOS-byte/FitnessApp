package com.example.project05122017;

import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Environment;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.ServerSocket;
import java.net.URI;
import java.util.concurrent.ExecutionException;

public class MainActivity extends AppCompatActivity{
    EditText pass;
    EditText log;
    String name;
    TextView tv;
    Button buttonNew;
    Button buttonLogIn;
    String realLog="";
    String realPass="";
    boolean save=false;
    String mail;
    int height;
    int wight;
    int vzlomAk=0,a=0;
    final String LOG_TAG = "myLogs";
    final String filename="FileToRegistr";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        log=(EditText)findViewById(R.id.editText1);
        pass=(EditText)findViewById(R.id.editText0);
        try{//toast
            BufferedReader bufferedReader=new BufferedReader(new InputStreamReader(openFileInput(filename)));
            if((realLog=bufferedReader.readLine())!=null){
                log.setText(realLog);
                realPass=bufferedReader.readLine();
                name=bufferedReader.readLine();}
        } catch (IOException ignored) {}
        //из файла
        tv=(TextView)findViewById(R.id.tv0);
        buttonNew = (Button) findViewById(R.id.buttonNew);
        buttonLogIn = (Button) findViewById(R.id.buttonLogIn);
    }
    public boolean isOnline(){
        ConnectivityManager cm=(ConnectivityManager)getSystemService(Context.CONNECTIVITY_SERVICE);
        try{
            NetworkInfo netInfo=cm.getActiveNetworkInfo();
            return netInfo!=null&&netInfo.isConnectedOrConnecting();
        }
        catch (NullPointerException e){
            return false;
        }

    }


    public void onClickMain(View view) throws InterruptedException {
        switch (view.getId()){
            case R.id.switch0:
            {
                a++;
                save=a%2!=0;
                break;
            }
            case R.id.buttonLogIn:{
                buttonLogIn.setClickable(false);
                if (realLog.equals("")){
                if (isOnline()){
                    try {
                        realLog=new Sender().execute("read",log.getText().toString(),"log").get();
                        Log.d(LOG_TAG,"loginning");
                        realPass=new Sender().execute("read",log.getText().toString(),"pass").get();
                        Log.d(LOG_TAG,"pass");
                        mail=new Sender().execute("read",log.getText().toString(),"mail").get();
                        height=Integer.parseInt(new Sender().execute("read",log.getText().toString(),"hight").get());
                        wight=Integer.parseInt(new Sender().execute("read",log.getText().toString(),"weight").get());
                        name=new Sender().execute("read",log.getText().toString(),"name").get();
                        Log.d(LOG_TAG,"name");
                    } catch (ExecutionException e) {
                        e.printStackTrace();
                    }

                    if (realLog.equals("ERROR ANSWER")){
                        tv.setText("Server is not available");
                        buttonLogIn.setClickable(true);
                        break;
                    }
                    if (realLog.equals("ERROR")){
                        tv.setText("No such Login");
                        buttonLogIn.setClickable(true);
                        break;
                    }
                    if (save){
                    try {
                        File file=new File(getApplicationContext().getFilesDir()+"/"+"MyFyles","FileToRegistr");
                        FileOutputStream outputStream=openFileOutput("FileToRegistr", Context.MODE_PRIVATE);
                        outputStream.write((realLog+"\n").getBytes());
                        outputStream.write((realPass+"\n").getBytes());
                        outputStream.write((name+"\n").getBytes());
                        outputStream.write((mail+"\n").getBytes());
                        outputStream.write((height+"\n").getBytes());
                        outputStream.write((wight+"\n").getBytes());
                        outputStream.close();
                    }
                    catch (IOException ignored) {}//из базы данных
                }}
                else{
                    tv.setText("No network connection! Please, try to LogIn after resume coonection.");
                    buttonLogIn.setClickable(true);
                    break;
                }}
                if (log.getText().toString().equals(realLog)){
                    if(pass.getText().toString().equals(realPass)){
                        //отдельная проверка логин  пароль
                        Intent intent =  new Intent(this, HomeActivity.class);
                        intent.putExtra("login",realLog);
                        intent.putExtra("password",realPass);
                        startActivity(intent);
                        Toast.makeText(getApplicationContext(), "Welcome, "+name+"!", Toast.LENGTH_SHORT).show();}
                    else{
                        tv.setText("Password are not correct! Try again!");
                    }
                }
                else{
                    tv.setText("Login are not correct! Try again!");
                }
                buttonLogIn.setClickable(true);
                break;}
            case R.id.buttonNew:{
                if(isOnline()){
                    getApplicationContext().deleteFile("FileToRegistr");
                    getApplicationContext().deleteFile("FileToResults");
                    getApplicationContext().deleteFile("FileToRecords");
                    Intent intent1 = new Intent(this, RegistrationActivity.class);
                    startActivity(intent1);}
                else
                    tv.setText("No network connection! Please, try to LogIn after resume coonection.");
                break;}
            default:
                break;
        }
    }
}
